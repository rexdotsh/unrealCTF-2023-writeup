import logging
import os
import subprocess
import uuid

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
)

app = Flask(__name__)
storage_dir = "/tmp/"

app.config["MAX_CONTENT_LENGTH"] = 1 * 1000 * 1000  # max content size 1mb
app.config["SECRET_KEY"] = os.urandom(32)


@app.route("/", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        return render_template("index.html")

    if "file" not in request.files:
        flash("where file?????? ", "danger")
        return render_template("index.html")

    file = request.files["file"]
    if os.path.splitext(file.filename)[1] != ".zip":
        flash("only zip files allowed", "danger")
        return render_template("index.html")

    random_id = str(uuid.uuid4())
    filename = f"{storage_dir}raw/{random_id}.zip"
    file.save(filename)
    subprocess.call(["unzip", filename, "-d", f"{storage_dir}files/{random_id}"])
    flash(f'ur file is at <a href="/files/{random_id}">{random_id}</a>!', "success")
    logging.info(f"user uploaded file {random_id}")
    return redirect("/")


@app.route("/files/<path:path>")
def files(path):
    try:
        return send_from_directory(storage_dir + "files", path)
    except PermissionError:
        abort(404)


@app.errorhandler(404)
def page_not_found(error):
    return render_template("404.html")
