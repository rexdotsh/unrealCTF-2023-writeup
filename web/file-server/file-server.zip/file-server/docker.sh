#!/bin/bash
sudo docker container stop file-server
sudo docker container remove file-server
sudo docker image rm file-server
sudo docker build -t "file-server" .
sudo docker run -d -p "0.0.0.0:1337:1337" -h "file-server" --name="file-server" file-server