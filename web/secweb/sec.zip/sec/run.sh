#!/bin/bash
sudo docker container stop sec
sudo docker container remove sec
sudo docker image rm sec
sudo docker build -t "sec" .
sudo docker run -d -p "0.0.0.0:5341:5341" -h "sec" --name="sec" sec